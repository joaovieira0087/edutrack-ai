def processar_ra_em_pares():
    """
    Esta função solicita o R.A. e o exibe em pares de
    dígitos, cada par em uma nova linha.
    """
    # Solicita a entrada do usuário
    ra_str = input("Digite seu R.A.: ")

    # Validação: O método .isdigit() verifica se a string contém apenas dígitos.
    # O 'not' inverte o resultado, então este 'if' é executado se a string
    # contiver qualquer caractere que NÃO seja um dígito (letra, espaço, etc.).
    if not ra_str.isdigit():
        print("Entrada inválida. Por favor, digite apenas números.")
        return

    print("\nO R.A. processado em pares é:")
    # Itera através da string com um passo de 2
    for i in range(0, len(ra_str), 2):
        # Pega o par de dígitos (ou o último dígito se o comprimento for ímpar)
        par = ra_str[i:i+2]
        print(par)

# Bloco principal para executar a função
if __name__ == "__main__":
    processar_ra_em_pares()
