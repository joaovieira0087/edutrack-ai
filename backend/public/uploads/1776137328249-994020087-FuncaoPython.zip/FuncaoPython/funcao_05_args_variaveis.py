# Exemplo 5: Argumentos de Tamanho Variável (*args)
#
# Às vezes, você não sabe quantos argumentos serão passados para sua função.
# O Python permite que uma função colete um número arbitrário de argumentos posicionais
# em uma tupla. A convenção é usar o nome '*args'.

def somar_todos(*numeros):
    """
    Esta função recebe um número variável de argumentos e soma todos eles.
    O parâmetro '*numeros' se torna uma tupla com todos os argumentos passados.
    """
    print(f"Argumentos recebidos: {numeros}") # Veja como 'numeros' é uma tupla
    
    soma = 0
    for numero in numeros:
        soma += numero
    return soma

# --- Como usar a função ---

# Chamando com 2 argumentos
print(f"Soma(1, 2) = {somar_todos(1, 2)}")
print("-" * 20)

# Chamando com 5 argumentos
print(f"Soma(10, 20, 30, 40, 50) = {somar_todos(10, 20, 30, 40, 50)}")
print("-" * 20)

# Chamando sem argumentos
print(f"Soma() = {somar_todos()}")
print("-" * 20)
