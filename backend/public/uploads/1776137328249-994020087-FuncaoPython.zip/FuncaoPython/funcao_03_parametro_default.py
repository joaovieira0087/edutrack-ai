# Exemplo 3: Função com Parâmetro de Valor Padrão (Default)
#
# Podemos definir um valor padrão para um ou mais parâmetros.
# Se um valor não for fornecido para esse parâmetro ao chamar a função,
# o valor padrão será utilizado.

def saudacao(nome, saudacao_texto="Olá"):
    """
    Esta função cria uma saudação.
    O parâmetro 'nome' é obrigatório.
    O parâmetro 'saudacao_texto' é opcional e seu valor padrão é "Olá".
    """
    print(f"{saudacao_texto}, {nome}!")

# --- Como usar a função ---

# 1. Chamando a função sem fornecer o parâmetro 'saudacao_texto'.
#    Neste caso, o valor padrão "Olá" será usado.
saudacao("Ana") # Saída: Olá, Ana!

# 2. Chamando a função e fornecendo ambos os parâmetros.
#    O valor padrão é ignorado e o valor fornecido ("Bem-vindo") é usado.
saudacao("Carlos", "Bem-vindo") # Saída: Bem-vindo, Carlos!

# 3. Outro exemplo
saudacao("Maria", "Bom dia") # Saída: Bom dia, Maria!
