# Esta é uma função que soma dois números
def somar(a, b):
  """
  Esta função recebe dois números como parâmetros e retorna a soma deles.
  """
  # A variável 'resultado' armazena a soma de a e b
  resultado = a + b
  # A função retorna o valor da variável 'resultado'
  return resultado

# Exemplo de como usar a função
numero1 = 5
numero2 = 3
soma = somar(numero1, numero2)

# Imprime o resultado no console
print(f"A soma de {numero1} e {numero2} é {soma}")
