# Exemplo 9: Funções como Parâmetros (Higher-Order Functions)
#
# Em Python, as funções são "cidadãos de primeira classe". Isso significa que
# elas podem ser tratadas como qualquer outro valor: podem ser atribuídas a variáveis,
# armazenadas em listas e, o mais importante para este exemplo,
# passadas como argumentos para outras funções.

# --- Funções de operação ---
def somar(a, b):
    return a + b

def subtrair(a, b):
    return a - b

def multiplicar(a, b):
    return a * b

# --- Função que recebe outra função como parâmetro ---
def aplicar_operacao(operacao, num1, num2):
    """
    Esta função recebe:
    - 'operacao': uma função que será aplicada aos números.
    - 'num1', 'num2': os números a serem operados.
    
    Ela então chama a função 'operacao' passando 'num1' e 'num2' como argumentos.
    """
    print(f"
Aplicando a operação '{operacao.__name__}' com {num1} e {num2}")
    resultado = operacao(num1, num2) # Aqui a mágica acontece!
    print(f"Resultado: {resultado}")
    return resultado

# --- Como usar a função ---

# Passando a função 'somar' como argumento
aplicar_operacao(somar, 10, 5)

# Passando a função 'subtrair' como argumento
aplicar_operacao(subtrair, 10, 5)

# Passando a função 'multiplicar' como argumento
aplicar_operacao(multiplicar, 10, 5)
