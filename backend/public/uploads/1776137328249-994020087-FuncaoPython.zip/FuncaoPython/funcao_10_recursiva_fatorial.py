# Exemplo 10: Função Recursiva (Fatorial)
#
# Recursão é um conceito onde uma função chama a si mesma para resolver um problema.
# Uma função recursiva deve ter duas partes:
# 1. Caso Base: Uma condição que para a recursão (para não entrar em loop infinito).
# 2. Passo Recursivo: A parte onde a função chama a si mesma, mas com um
#    argumento que se aproxima do caso base.

# O fatorial de um número n (n!) é o produto de todos os inteiros de 1 a n.
# Ex: 5! = 5 * 4 * 3 * 2 * 1 = 120
# Podemos definir isso recursivamente:
# 5! = 5 * 4!
# 4! = 4 * 3!
# ...
# 1! = 1
# 0! = 1 (por definição)

def fatorial(n):
    """
    Calcula o fatorial de um número 'n' usando recursão.
    """
    # 1. Caso Base: Se n for 0 ou 1, o fatorial é 1. Isso para a "descida".
    if n == 0 or n == 1:
        print(f"Caso base: fatorial({n}) = 1")
        return 1
    # 2. Passo Recursivo: Se n > 1, n! = n * (n-1)!
    else:
        print(f"Passo recursivo: fatorial({n}) = {n} * fatorial({n-1})")
        resultado = n * fatorial(n - 1)
        print(f"Retornando o resultado de {n} * fatorial({n-1}): {resultado}")
        return resultado

# --- Como usar a função ---
numero = 4
print(f"
Calculando o fatorial de {numero}...
")
resultado_final = fatorial(numero)
print(f"
O fatorial de {numero} é: {resultado_final}")
