# Exemplo 8: Escopo de Variáveis (Local vs. Global)
#
# O "escopo" de uma variável é a parte do programa onde ela é acessível.

# --- Variável Global ---
# Esta variável é definida fora de qualquer função, então ela é "global".
# Pode ser acessada de qualquer lugar no script, inclusive dentro de funções.
variavel_global = "Eu sou global!"

def minha_funcao():
    """
    Esta função demonstra o uso de variáveis locais e globais.
    """
    # --- Variável Local ---
    # Esta variável é definida DENTRO da função, então ela é "local".
    # Ela só existe e pode ser acessada dentro desta função.
    variavel_local = "Eu sou local!"
    
    print("--- Dentro da Função ---")
    print(f"Acessando a variável local: '{variavel_local}'")
    print(f"Acessando a variável global: '{variavel_global}'")
    
    # Se quisermos modificar uma variável global dentro de uma função,
    # precisamos usar a palavra-chave 'global'. (Uso não recomendado em geral)
    global variavel_global
    variavel_global = "A variável global foi modificada!"

# --- Fora da Função ---

print("--- Antes de chamar a função ---")
print(f"Valor da variável global: '{variavel_global}'")

# Chamando a função
minha_funcao()

print("
--- Depois de chamar a função ---")
print(f"Novo valor da variável global: '{variavel_global}'")

# Tentando acessar a variável local fora da função.
# A linha abaixo causará um ERRO (NameError), pois 'variavel_local' não existe aqui.
# print(variavel_local) # Descomente esta linha para ver o erro.
