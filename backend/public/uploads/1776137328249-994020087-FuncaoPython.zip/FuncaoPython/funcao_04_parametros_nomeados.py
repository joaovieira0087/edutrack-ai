# Exemplo 4: Argumentos Nomeados (Keyword Arguments)
#
# Ao chamar uma função, você pode especificar qual argumento corresponde a qual parâmetro
# usando o nome do parâmetro. Isso torna o código mais legível e permite
# alterar a ordem dos argumentos.

def descrever_animal(nome, especie, idade):
    """
    Esta função descreve um animal com base nos seus dados.
    """
    print(f"--- Ficha do Animal ---")
    print(f"Nome: {nome}")
    print(f"Espécie: {especie}")
    print(f"Idade: {idade} anos")

# --- Como usar a função ---

# 1. Chamada tradicional (argumentos posicionais).
#    A ordem importa: "Rex" vai para 'nome', "Cachorro" para 'especie', etc.
print("Chamada com argumentos posicionais:")
descrever_animal("Rex", "Cachorro", 5)

print("
" + "-"*20 + "
") # Apenas para separar as saídas

# 2. Chamada com argumentos nomeados.
#    A ordem não importa, pois estamos nomeando cada argumento.
#    Isso deixa o código muito mais claro.
print("Chamada com argumentos nomeados:")
descrever_animal(idade=3, nome="Mimi", especie="Gato")

# 3. Misturando os dois (posicionais primeiro, depois nomeados).
#    Primeiro vêm os posicionais, depois os nomeados.
#    descrever_animal(nome="Fido", 5, "Cachorro") # ISSO DARIA ERRO!
descrever_animal("Fido", idade=2, especie="Pássaro")
