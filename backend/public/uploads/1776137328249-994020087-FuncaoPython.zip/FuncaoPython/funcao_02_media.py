# Exemplo 2: Função para Calcular a Média
#
# Funções podem trabalhar com diferentes tipos de dados, como listas.

def calcular_media(lista_de_numeros):
    """
    Esta função recebe uma lista de números, calcula a média
    e retorna o resultado.
    """
    # A função 'sum()' é uma função embutida do Python que soma os itens de uma lista.
    total = sum(lista_de_numeros)
    
    # A função 'len()' é outra função embutida que retorna o número de itens em uma lista.
    quantidade = len(lista_de_numeros)
    
    # Evita divisão por zero se a lista estiver vazia.
    if quantidade == 0:
        return 0
        
    media = total / quantidade
    return media

# --- Como usar a função ---

# Criamos uma lista de notas.
notas_aluno1 = [8.5, 7.0, 9.0, 10.0]

# Passamos a lista para a nossa função.
media_aluno1 = calcular_media(notas_aluno1)

print(f"A média do aluno 1 é: {media_aluno1}")

# Outro exemplo com uma lista diferente.
notas_aluno2 = [5.5, 6.0, 7.5]
media_aluno2 = calcular_media(notas_aluno2)

print(f"A média do aluno 2 é: {media_aluno2:.2f}") # Formata a saída para ter 2 casas decimais.
