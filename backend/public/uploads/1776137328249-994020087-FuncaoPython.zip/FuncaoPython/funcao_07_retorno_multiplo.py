# Exemplo 7: Função com Retorno de Múltiplos Valores
#
# No Python, uma função pode retornar múltiplos valores de uma vez.
# Tecnicamente, a função retorna uma única tupla, mas o Python
# permite "desempacotar" essa tupla em múltiplas variáveis.

def encontrar_min_max(lista):
    """
    Esta função encontra o menor e o maior número em uma lista
    e retorna ambos.
    """
    if not lista: # Se a lista estiver vazia
        return None, None
        
    menor = min(lista) # min() é uma função embutida do Python
    maior = max(lista) # max() também é uma função embutida
    
    return menor, maior # Retornando os dois valores

# --- Como usar a função ---

numeros = [4, 8, 1, 15, 9, 3]

# Chamamos a função e "desempacotamos" o resultado em duas variáveis.
# 'valor_minimo' receberá o primeiro valor retornado (menor).
# 'valor_maximo' receberá o segundo valor retornado (maior).
valor_minimo, valor_maximo = encontrar_min_max(numeros)

print(f"A lista de números é: {numeros}")
print(f"O menor valor na lista é: {valor_minimo}")
print(f"O maior valor na lista é: {valor_maximo}")

# O que acontece se tentarmos atribuir a uma única variável?
resultado_tupla = encontrar_min_max(numeros)
print(f"
O retorno na verdade é uma tupla: {resultado_tupla}")
