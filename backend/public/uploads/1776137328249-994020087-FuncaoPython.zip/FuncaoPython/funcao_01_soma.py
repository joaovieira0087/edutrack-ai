# Exemplo 1: Função de Soma Simples
#
# Uma função é um bloco de código que só é executado quando é chamado.
# Você pode passar dados, conhecidos como parâmetros, para uma função.
# Uma função pode retornar dados como resultado.

# A palavra-chave 'def' é usada para criar (definir) uma função.
# Aqui, 'numero1' e 'numero2' são os parâmetros da função 'somar'.
def somar(numero1, numero2):
    """
    Esta função recebe dois números como parâmetros e retorna a soma deles.
    O texto entre três aspas é uma "docstring", uma forma de documentar a função.
    """
    resultado = numero1 + numero2
    return resultado # A palavra-chave 'return' envia um valor de volta para onde a função foi chamada.

# --- Como usar a função ---

# Chamamos a função 'somar' com os argumentos 5 e 3.
soma = somar(5, 3)

# Imprimimos o resultado que a função retornou.
print(f"O resultado da soma é: {soma}") # Saída: O resultado da soma é: 8

# Também podemos chamar a função diretamente dentro de um print.
print(f"Outra soma: {somar(10, 20)}") # Saída: Outra soma: 30
