# Exemplo 6: Argumentos de Palavra-chave Variáveis (**kwargs)
#
# Semelhante ao *args, o **kwargs permite passar um número variável de
# argumentos de palavra-chave (nomeados) para uma função.
# A função recebe esses argumentos como um dicionário.
# A convenção é usar o nome '**kwargs' (keyword arguments).

def exibir_info_pessoa(**dados_pessoa):
    """
    Esta função recebe dados de uma pessoa como argumentos de palavra-chave
    e os exibe. 'dados_pessoa' será um dicionário.
    """
    print("Informações Recebidas:")
    print(f"Tipo de dados_pessoa: {type(dados_pessoa)}") # Veja que é um dicionário (dict)
    
    for chave, valor in dados_pessoa.items():
        print(f"- {chave.replace('_', ' ').capitalize()}: {valor}")

# --- Como usar a função ---

print("Exibindo dados de João:")
exibir_info_pessoa(nome="João", idade=28, cidade="São Paulo")

print("
" + "-"*20 + "
")

print("Exibindo dados de Maria:")
# Note que podemos passar diferentes "chaves" de informação
exibir_info_pessoa(nome="Maria", profissao="Engenheira", email="maria@email.com", tem_filhos=False)
